module.exports.pluginFile = 'bimadplugin.js';
module.exports.baseURL = 'http://10.0.137.125:9502/mobile/';

